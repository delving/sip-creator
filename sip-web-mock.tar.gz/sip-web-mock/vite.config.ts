import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { createLocalDataPlugin } from './tools/localDataPlugin';

export default defineConfig({
  plugins: [react(), createLocalDataPlugin()],
  server: {
    host: '0.0.0.0',
    port: 5173
  }
});
