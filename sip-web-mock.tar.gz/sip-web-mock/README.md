# SIP Web Mock

A React + Tailwind proof-of-concept that reimagines the SIP-Creator Swing workspace as a web experience. It renders the critical surfaces (Datasets, Quick Mapping, Big Picture, Code Tweaking) using static fixtures so stakeholders can evaluate layouts and interactions before wiring to the Java backend.

## Getting started

```bash
npm install
npm run dev
```

> **Note:** this repository does not vendor `node_modules`. Run the commands above from within `sip-web-mock/` to pull the dependencies and launch the Vite dev server on port `5173`.

## Local workspace integration

Running `npm run dev` exposes a few helper endpoints that read the current SIP workspace under `/home/kiivihal/PocketMapper/dcn/PocketMapper`:

- `GET /api/credentials` – reads `sip-creator.properties` to pre-fill the Narthex login modal.
- `GET /api/local-datasets` – enumerates downloaded datasets grouped by spec, extracting facts from `sip.json`/`narthex_facts.txt`.
- `GET /api/upload-queue` – lists SIP zips staged for upload.
- `POST /api/remote-datasets` – proxies to `https://<narthex>/sip-app` using basic auth and folds the XML response into a summary list (falls back to fixtures if the request fails).

These routes power the new datasets mock. If the workspace cannot be read, the UI falls back to bundled fixtures and highlights the degraded state.

## Architecture

- **React + Vite** drives the single-page shell located in `src/`.
- **Tailwind CSS** provides styling primitives; configure themes in `tailwind.config.js`.
- **Zustand** keeps track of workspace state (current view, selected dataset, pipeline tasks).
- **Fixtures** derived from the Amsterdam Museum SIP package live under `src/data/` and mock datasets, mapping pairs, pipeline stages, and Groovy snippets.

## Next steps

1. Replace static fixtures with service calls to the Java backend (REST/gRPC adapters).
2. Introduce routing and persisted workspace preferences.
3. Swap the textarea mock editor for Monaco and embed Recharts/D3 for richer analytics.
4. Implement real download/upload flows once HTTP endpoints are available.
