import fs from 'node:fs';
import path from 'node:path';
import { URL } from 'node:url';
import type { Plugin } from 'vite';
import { XMLParser } from 'fast-xml-parser';

const WORKSPACE_ROOT = '/home/kiivihal/PocketMapper/dcn/PocketMapper';
const PROPERTIES_FILE = path.join(WORKSPACE_ROOT, 'sip-creator.properties');
const WORK_DIR = path.join(WORKSPACE_ROOT, 'work');
const UPLOAD_DIR = path.join(WORKSPACE_ROOT, 'up');

const REMOTE_DATASET_STUB = [
  {
    spec: 'amsterdam-museum',
    title: 'Amsterdam Museum',
    orgId: 'dcn',
    latestVersion: '2025-01-12T10:30:00Z',
    availableVersions: 6,
    status: 'published'
  },
  {
    spec: 'anne-frank-stichting',
    title: 'Anne Frank Stichting',
    orgId: 'dcn',
    latestVersion: '2025-04-01T12:57:00Z',
    availableVersions: 9,
    status: 'draft'
  },
  {
    spec: 'museum-weesp',
    title: 'Museum Weesp',
    orgId: 'dcn',
    latestVersion: '2025-02-03T09:32:00Z',
    availableVersions: 3,
    status: 'published'
  },
  {
    spec: 'catharijneconvent',
    title: 'Museum Catharijneconvent',
    orgId: 'dcn',
    latestVersion: '2025-09-02T08:05:00Z',
    availableVersions: 4,
    status: 'archived'
  }
];

const toIso = (date: Date) => date.toISOString();

const parseProperties = (content: string) => {
  const result: Record<string, string> = {};
  content
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#'))
    .forEach((line) => {
      const idx = line.indexOf('=');
      if (idx > -1) {
        const key = line.substring(0, idx).trim();
        const value = line.substring(idx + 1).trim().replace(/\\:/g, ':');
        result[key] = value;
      }
    });
  return result;
};

const readJsonFile = <T>(filePath: string): T | undefined => {
  try {
    if (fs.existsSync(filePath)) {
      const raw = fs.readFileSync(filePath, 'utf-8');
      return JSON.parse(raw) as T;
    }
  } catch {
    // ignore parsing errors for fixtures
  }
  return undefined;
};

const readFactsTxt = (filePath: string) => {
  const facts: Record<string, string> = {};
  if (!fs.existsSync(filePath)) return facts;
  const raw = fs.readFileSync(filePath, 'utf-8');
  raw
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#'))
    .forEach((line) => {
      const idx = line.indexOf('=');
      if (idx > -1) {
        const key = line.substring(0, idx).trim();
        const value = line.substring(idx + 1).trim();
        facts[key] = value;
      }
    });
  return facts;
};

const parseVersionFromDir = (dirName: string) => {
  const withoutSuffix = dirName.replace(/\.sip\.zip$/, '');
  const [spec, timestamp] = withoutSuffix.split('__');
  if (!timestamp) {
    return { spec: withoutSuffix, timestampLabel: 'Unknown', iso: undefined };
  }
  const parts = timestamp.split('_').map((part) => parseInt(part, 10));
  if (parts.length < 5 || parts.some((part) => Number.isNaN(part))) {
    return { spec, timestampLabel: timestamp.replace(/_/g, '-'), iso: undefined };
  }
  const [year, month, day, hour, minute] = parts;
  const iso = new Date(Date.UTC(year, month - 1, day, hour, minute));
  const label = iso.toLocaleString('en-GB', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
  return { spec, timestampLabel: label, iso: iso.toISOString() };
};

const deriveDataSetState = (folderPath: string) => {
  const mappingFiles = fs
    .readdirSync(folderPath)
    .filter((file) => file.startsWith('mapping_') && file.endsWith('.xml'));
  const reportJson = path.join(folderPath, 'report.json');
  const statsSource = path.join(folderPath, 'stats-source.xml.gz');
  const hasMapping = mappingFiles.length > 0 || fs.existsSync(path.join(folderPath, 'mapping_edm.xml'));
  const hasReport = fs.existsSync(reportJson);
  const hasStats = fs.existsSync(statsSource);
  if (hasReport) return 'processed';
  if (hasMapping) return 'mapping';
  if (hasStats) return 'analyzed';
  return 'sourced';
};

const readLocalDatasets = () => {
  if (!fs.existsSync(WORK_DIR)) {
    return { root: WORK_DIR, groups: [] as any[] };
  }
  const entries = fs.readdirSync(WORK_DIR, { withFileTypes: true });
  const groupMap = new Map<string, any>();

  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    const folderName = entry.name;
    if (!folderName.endsWith('.sip.zip')) continue;
    const folderPath = path.join(WORK_DIR, folderName);
    const { spec, timestampLabel, iso } = parseVersionFromDir(folderName);
    const factsJsonPath = path.join(folderPath, 'sip.json');
    const hintsPath = path.join(folderPath, 'narthex_facts.txt');

    const factsJson = readJsonFile<{ facts?: Record<string, string> }>(factsJsonPath);
    const factsFromJson = factsJson?.facts ?? {};
    const factsTxt = readFactsTxt(hintsPath);
    const facts = { ...factsTxt, ...factsFromJson };

    const stat = fs.statSync(folderPath);
    const schemaVersion = facts.schemaVersions ?? facts.schemaVersion ?? 'unknown';
    const displayName = facts.name ?? spec;

    const version = {
      id: folderName,
      label: timestampLabel,
      timestamp: iso ?? toIso(stat.mtime),
      folderPath,
      schemaVersion,
      state: deriveDataSetState(folderPath),
      facts
    };

    if (!groupMap.has(spec)) {
      groupMap.set(spec, {
        spec,
        title: displayName,
        orgId: facts.orgId ?? 'unknown',
        type: facts.type ?? 'UNKNOWN',
        schemaVersion,
        versions: [] as any[]
      });
    }
    groupMap.get(spec)!.versions.push(version);
  }

  const groups = Array.from(groupMap.values()).map((group) => {
    const sorted = group.versions.sort((a, b) => (a.timestamp < b.timestamp ? 1 : -1));
    const latest = sorted[0];
    return {
      ...group,
      versions: sorted,
      latestTimestamp: latest?.timestamp ?? null,
      versionCount: group.versions.length
    };
  });

  groups.sort((a, b) => {
    if (!a.latestTimestamp || !b.latestTimestamp) return a.spec.localeCompare(b.spec);
    return a.latestTimestamp < b.latestTimestamp ? 1 : -1;
  });

  return {
    root: WORK_DIR,
    groups
  };
};

const readUploadQueue = () => {
  if (!fs.existsSync(UPLOAD_DIR)) {
    return { root: UPLOAD_DIR, items: [] as any[] };
  }
  const entries = fs.readdirSync(UPLOAD_DIR, { withFileTypes: true });
  const items = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith('.sip.zip'))
    .map((entry) => {
      const filePath = path.join(UPLOAD_DIR, entry.name);
      const stats = fs.statSync(filePath);
      const withoutSuffix = entry.name.replace(/\.sip\.zip$/, '');
      const parts = withoutSuffix.split('__');
      const spec = parts[0];
      const schema = parts[parts.length - 1];
      return {
        file: entry.name,
        spec,
        schema,
        size: stats.size,
        modified: toIso(stats.mtime)
      };
    })
    .sort((a, b) => (a.modified < b.modified ? 1 : -1));

  return {
    root: UPLOAD_DIR,
    items
  };
};

const parseBody = async (req: any) => {
  const chunks: Buffer[] = [];
  for await (const chunk of req) {
    chunks.push(chunk as Buffer);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf-8'));
  } catch {
    return {};
  }
};

const respondJson = (res: any, data: unknown, status = 200) => {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
};

const readCredentials = () => {
  if (!fs.existsSync(PROPERTIES_FILE)) {
    return {
      narthexUrl: '',
      narthexUsername: '',
      narthexPassword: ''
    };
  }
  const raw = fs.readFileSync(PROPERTIES_FILE, 'utf-8');
  const parsed = parseProperties(raw);
  return {
    narthexUrl: parsed['narthexUrl'] ?? '',
    narthexUsername: parsed['narthexUsername'] ?? '',
    narthexPassword: parsed['narthexPassword'] ?? ''
  };
};

export const createLocalDataPlugin = (): Plugin => ({
  name: 'local-data-plugin',
  configureServer(server) {
    server.middlewares.use(async (req, res, next) => {
      if (!req.url) return next();
      const requestUrl = new URL(req.url, 'http://localhost');
      const { pathname } = requestUrl;

      if (pathname === '/api/credentials' && req.method === 'GET') {
        return respondJson(res, {
          credentials: readCredentials(),
          source: PROPERTIES_FILE
        });
      }

      if (pathname === '/api/local-datasets' && req.method === 'GET') {
        return respondJson(res, readLocalDatasets());
      }

      if (pathname === '/api/upload-queue' && req.method === 'GET') {
        return respondJson(res, readUploadQueue());
      }

      if (pathname === '/api/remote-datasets' && req.method === 'POST') {
        const body = await parseBody(req);
        const { narthexUrl, narthexUsername, narthexPassword } = body ?? {};
        if (!narthexUrl || !narthexUsername || !narthexPassword) {
          return respondJson(res, { error: 'Missing credentials' }, 400);
        }
        try {
          const data = await fetchRemoteDatasets(narthexUrl, narthexUsername, narthexPassword);
          return respondJson(res, data);
        } catch (error: any) {
          console.warn('Remote dataset fetch failed, falling back to stub:', error);
          const status = error?.status === 401 ? 401 : 502;
          return respondJson(
            res,
            {
              fetchedAt: new Date().toISOString(),
              datasets: REMOTE_DATASET_STUB,
              error: error?.message ?? 'Unable to reach Narthex'
            },
            status
          );
        }
      }

      next();
    });
  }
});
const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
  textNodeName: 'value',
  parseAttributeValue: true,
  trimValues: true
});

const normalizeArray = <T,>(value: T | T[] | undefined): T[] => {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
};

type RemoteDatasetSummary = {
  spec: string;
  title: string;
  orgId: string;
  latestVersion: string;
  availableVersions: number;
  status: 'published' | 'draft' | 'archived';
};

const parseRemoteDatasets = (xml: string): RemoteDatasetSummary[] => {
  try {
    const parsed = parser.parse(xml);
    const root = parsed['sip-zips'];
    if (!root) return [];
    const availableEntries = normalizeArray<any>(root.available?.['sip-zip']);
    if (!availableEntries.length) return [];

    const grouped = new Map<string, { spec: string; files: string[] }>();

    for (const entry of availableEntries) {
      const dataset = entry?.dataset ?? entry?.['dataset'];
      const file = entry?.file ?? entry?.['file'];
      if (!dataset || !file) continue;
      if (!grouped.has(dataset)) {
        grouped.set(dataset, { spec: dataset, files: [] });
      }
      grouped.get(dataset)!.files.push(file);
    }

    const summaries: RemoteDatasetSummary[] = [];

    const parseTimestampFromFile = (fileName: string) => {
      const withoutSuffix = fileName.replace(/\.sip\.zip$/i, '');
      const parts = withoutSuffix.split('__');
      const timestampFragment = parts.length > 1 ? parts[parts.length - 1] : '';
      const tokens = timestampFragment.split('_').map((token) => parseInt(token, 10));
      if (tokens.length < 5 || tokens.some((token) => Number.isNaN(token))) {
        return null;
      }
      const [year, month, day, hour, minute] = tokens;
      const date = new Date(Date.UTC(year, month - 1, day, hour, minute));
      return Number.isNaN(date.getTime()) ? null : date.toISOString();
    };

    for (const { spec, files } of grouped.values()) {
      if (!files.length) continue;
      const sorted = files
        .map((file) => ({ file, iso: parseTimestampFromFile(file) }))
        .sort((a, b) => {
          if (!a.iso || !b.iso) return 0;
          return a.iso < b.iso ? 1 : -1;
        });

      const latest = sorted[0];
      summaries.push({
        spec,
        title: spec,
        orgId: root.orgId ?? 'unknown',
        latestVersion: latest?.iso ?? new Date().toISOString(),
        availableVersions: files.length,
        status: 'published'
      });
    }

    return summaries
      .sort((a, b) => a.spec.localeCompare(b.spec))
      .map((summary) => summary);
  } catch (error) {
    console.warn('Failed to parse remote dataset XML:', error);
    return [];
  }
};

const fetchRemoteDatasets = async (
  narthexUrl: string,
  username: string,
  password: string
): Promise<{ datasets: RemoteDatasetSummary[]; fetchedAt: string }> => {
  const sanitizedUrl = narthexUrl.replace(/\/?$/, '');
  const endpoint = `${sanitizedUrl}/sip-app`;
  const response = await fetch(endpoint, {
    headers: {
      Accept: 'text/xml',
      Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`
    }
  });

  if (response.status === 401) {
    throw Object.assign(new Error('Unauthorized'), { status: 401 });
  }

  if (!response.ok) {
    const text = await response.text().catch(() => '');
    throw Object.assign(new Error(`Unexpected response ${response.status}`), {
      status: response.status,
      body: text
    });
  }

  const xml = await response.text();
  const datasets = parseRemoteDatasets(xml);
  return {
    datasets: datasets.length ? datasets : REMOTE_DATASET_STUB,
    fetchedAt: new Date().toISOString()
  };
};
