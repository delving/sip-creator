import { ReactNode } from 'react';
import { useWorkspaceStore } from '../state/workspaceStore';
import { views } from '../views/viewRegistry';

const ViewSwitcher = () => {
  const current = useWorkspaceStore((state) => state.view);
  const setView = useWorkspaceStore((state) => state.setView);

  return (
    <div className="flex gap-2">
      {views.map((view) => (
        <button
          key={view.id}
          onClick={() => setView(view.id)}
          className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-brand focus-visible:ring-offset-2 focus-visible:ring-offset-slate-900 ${
            current === view.id
              ? 'bg-brand text-white shadow'
              : 'bg-slate-800/60 text-slate-300 hover:bg-slate-700'
          }`}
        >
          {view.label}
        </button>
      ))}
    </div>
  );
};

const TopBar = () => {
  const dataset = useWorkspaceStore((state) =>
    state.datasets.find((item) => item.id === state.selectedDatasetId)
  );

  return (
    <header className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
      <div>
        <p className="text-xs uppercase tracking-widest text-slate-500">SIP Creator Mock</p>
        <h1 className="text-xl font-semibold text-white">Mapping Workbench</h1>
        {dataset ? (
          <p className="text-sm text-slate-400">
            Active dataset: <span className="font-medium text-slate-200">{dataset.name}</span> · EDM {dataset.schemaVersion}
          </p>
        ) : (
          <p className="text-sm text-slate-400">Select a dataset to begin</p>
        )}
      </div>
      <ViewSwitcher />
    </header>
  );
};

const StatusFooter = () => {
  const tasks = useWorkspaceStore((state) => state.tasks);

  return (
    <footer className="grid grid-cols-4 gap-4 border-t border-slate-800 px-6 py-3 text-xs text-slate-400">
      {tasks.map((task) => (
        <div key={task.id} className="flex flex-col gap-1">
          <span className="font-medium text-slate-300">{task.label}</span>
          <div className="h-1.5 rounded-full bg-slate-800">
            <div
              className={`h-full rounded-full ${
                task.state === 'done' ? 'bg-emerald-500' : task.state === 'running' ? 'bg-brand' : 'bg-slate-600'
              }`}
              style={{ width: `${task.progress}%` }}
            />
          </div>
          <span>{task.state === 'queued' ? 'Queued' : `${task.progress}%`}</span>
        </div>
      ))}
    </footer>
  );
};

export const AppLayout = ({ children }: { children: ReactNode }) => {
  return (
    <div className="flex h-full flex-col bg-slate-950 text-slate-100">
      <TopBar />
      <main className="flex-1 overflow-hidden">{children}</main>
      <StatusFooter />
    </div>
  );
};
