import { AppLayout } from './layouts/AppLayout';
import { useWorkspaceStore } from './state/workspaceStore';
import { views } from './views/viewRegistry';

export default function App() {
  const activeView = useWorkspaceStore((state) => state.view);
  const current = views.find((view) => view.id === activeView) ?? views[0];

  return <AppLayout>{current.element}</AppLayout>;
}
