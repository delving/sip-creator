export type HistogramBin = {
  key: string;
  count: number;
};

export type Histogram = {
  id: string;
  label: string;
  bins: HistogramBin[];
};

export const histograms: Histogram[] = [
  {
    id: 'language',
    label: 'Language Coverage',
    bins: [
      { key: 'nl', count: 17420 },
      { key: 'en', count: 520 },
      { key: 'fr', count: 42 }
    ]
  },
  {
    id: 'media',
    label: 'Media Type',
    bins: [
      { key: 'IMAGE', count: 18350 },
      { key: 'TEXT', count: 42 },
      { key: 'VIDEO', count: 8 }
    ]
  },
  {
    id: 'date-span',
    label: 'Creation Date Span',
    bins: [
      { key: 'pre-1700', count: 2120 },
      { key: '1700-1800', count: 3840 },
      { key: '1800-1900', count: 7220 },
      { key: '1900-1950', count: 3680 },
      { key: '1950+', count: 1572 }
    ]
  }
];

export type Activity = {
  time: string;
  message: string;
  level: 'info' | 'warning' | 'error';
};

export const recentActivity: Activity[] = [
  {
    time: '16:22',
    message: 'Mapping saved as version 42',
    level: 'info'
  },
  {
    time: '16:02',
    message: 'Schema validation flagged 4 records with missing edm:isShownAt',
    level: 'warning'
  },
  {
    time: '15:48',
    message: 'Source analysis completed (18,432 records)',
    level: 'info'
  }
];
