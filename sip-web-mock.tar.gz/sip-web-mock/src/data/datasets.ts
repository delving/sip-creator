export type DatasetStatus = 'idle' | 'sourced' | 'analyzed' | 'mapping' | 'processed';

export type Dataset = {
  id: string;
  orgId: string;
  spec: string;
  name: string;
  provider: string;
  schemaVersion: string;
  language: string;
  recordCount: number;
  type: string;
  rights: string;
  lastSynced: string;
  status: DatasetStatus;
  progress: number;
};

export const datasets: Dataset[] = [
  {
    id: 'amsterdam-museum',
    orgId: 'dcn',
    spec: 'amsterdam-museum',
    name: 'Amsterdam Museum',
    provider: 'Rijksdienst voor het Cultureel Erfgoed',
    schemaVersion: 'edm_5.2.6',
    language: 'nl',
    recordCount: 18432,
    type: 'IMAGE',
    rights: 'http://rightsstatements.org/vocab/InC/1.0/',
    lastSynced: '2025-01-09T16:22:00Z',
    status: 'mapping',
    progress: 62
  },
  {
    id: 'anne-frank-stichting',
    orgId: 'dcn',
    spec: 'anne-frank-stichting',
    name: 'Anne Frank Stichting',
    provider: 'Rijksdienst voor het Cultureel Erfgoed',
    schemaVersion: 'edm_5.2.6',
    language: 'nl',
    recordCount: 5432,
    type: 'IMAGE',
    rights: 'http://rightsstatements.org/vocab/InC/1.0/',
    lastSynced: '2025-03-20T10:52:00Z',
    status: 'processed',
    progress: 100
  },
  {
    id: 'museum-weesp',
    orgId: 'dcn',
    spec: 'museum-weesp',
    name: 'Museum Weesp',
    provider: 'Rijksdienst voor het Cultureel Erfgoed',
    schemaVersion: 'edm_5.2.6',
    language: 'nl',
    recordCount: 2450,
    type: 'IMAGE',
    rights: 'http://rightsstatements.org/vocab/InC/1.0/',
    lastSynced: '2025-02-03T09:32:00Z',
    status: 'analyzed',
    progress: 38
  }
];

export type MappingPair = {
  id: string;
  sourceField: string;
  targetField: string;
  transformation: 'copy' | 'concat' | 'lookup' | 'script';
  preview: string;
  status: 'complete' | 'needs-review' | 'missing';
};

export const mappingPairs: MappingPair[] = [
  {
    id: 'title',
    sourceField: 'edm:ProvidedCHO/dcterms:title',
    targetField: 'edm:ProvidedCHO/dc:title',
    transformation: 'copy',
    preview: '"Schuttersstuk van het Amsterdamse gilde"',
    status: 'complete'
  },
  {
    id: 'description',
    sourceField: 'edm:ProvidedCHO/dcterms:description',
    targetField: 'edm:ProvidedCHO/dcterms:description',
    transformation: 'concat',
    preview: '"Olieverfschilderij, beschrijving + datering"',
    status: 'needs-review'
  },
  {
    id: 'creator',
    sourceField: 'edm:ProvidedCHO/dc:creator',
    targetField: 'edm:ProvidedCHO/dc:creator',
    transformation: 'lookup',
    preview: '"Hals, Frans" → "Frans Hals (1582–1666)"',
    status: 'complete'
  },
  {
    id: 'identifier',
    sourceField: 'edm:ProvidedCHO/dc:identifier',
    targetField: 'edm:ProvidedCHO/dc:identifier',
    transformation: 'script',
    preview: 'buildUrl(record.identifier)',
    status: 'missing'
  }
];

export type PipelineStage = {
  id: string;
  title: string;
  description: string;
  state: 'pending' | 'in-progress' | 'done';
  owner: string;
  durationMinutes: number;
};

export const pipelineStages: PipelineStage[] = [
  {
    id: 'ingest',
    title: 'Ingest Source XML',
    description: 'Load source.xml.gz and normalize identifiers',
    state: 'done',
    owner: 'Storage',
    durationMinutes: 12
  },
  {
    id: 'analyze',
    title: 'Analyze Source Structure',
    description: 'Generate histograms and field coverage stats',
    state: 'done',
    owner: 'StatsModel',
    durationMinutes: 6
  },
  {
    id: 'map',
    title: 'Configure Mapping',
    description: 'Align source fields to EDM 5.2.6 targets',
    state: 'in-progress',
    owner: 'MappingModel',
    durationMinutes: 24
  },
  {
    id: 'validate',
    title: 'Validate Output',
    description: 'Run EDM schema validation & custom rules',
    state: 'pending',
    owner: 'Validation',
    durationMinutes: 0
  },
  {
    id: 'publish',
    title: 'Publish SIP Package',
    description: 'Compress artifacts and hand off to CultureHub',
    state: 'pending',
    owner: 'Deployment',
    durationMinutes: 0
  }
];

export const groovySnippet = `record.build { edmProvidedCHO {
  dcTitle source['dcterms:title']
  dcDescription join(source['dcterms:description'], '\n\n')
  dcCreator authorityLookup('rkd', source['dc:creator'])
  edmType source['edm:type'] ?: 'IMAGE'
  edmRights facts['rights']
}
oreAggregation {
  edmIsShownAt buildIiifManifest(record)
  edmObject thumbnailUrl(record)
  oreAggregates recordUri()
}
}`;
