import { useMemo, useState } from 'react';
import { mappingPairs } from '../../data/datasets';
import { useSelectedDataset, useWorkspaceStore } from '../../state/workspaceStore';

const getStatusStyles = (status: string) => {
  switch (status) {
    case 'complete':
      return 'bg-emerald-500/20 text-emerald-200 border border-emerald-500/40';
    case 'needs-review':
      return 'bg-amber-500/20 text-amber-200 border border-amber-500/40';
    default:
      return 'bg-rose-500/20 text-rose-200 border border-rose-500/40';
  }
};

export const QuickMappingView = () => {
  const dataset = useSelectedDataset();
  const pairs = useWorkspaceStore((state) => state.mappingPairs);
  const updateMappingStatus = useWorkspaceStore((state) => state.updateMappingStatus);
  const [selectedMappingId, setSelectedMappingId] = useState(pairs[0]?.id ?? mappingPairs[0].id);
  const selectedMapping = pairs.find((pair) => pair.id === selectedMappingId) ?? pairs[0];

  const coverage = useMemo(() => {
    const total = pairs.length;
    const complete = pairs.filter((pair) => pair.status === 'complete').length;
    return Math.round((complete / total) * 100);
  }, [pairs]);

  return (
    <div className="grid h-full grid-cols-[18rem_20rem_minmax(0,1fr)] gap-6 px-6 py-6">
      <aside className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
        <header>
          <h2 className="text-lg font-semibold text-slate-100">Source Fields</h2>
          <p className="text-xs text-slate-500">Derived from {dataset?.spec ?? 'unknown spec'}</p>
        </header>
        <div className="mt-4 flex-1 overflow-y-auto pr-1 text-xs">
          <ul className="space-y-1 text-slate-300">
            {pairs.map((pair) => (
              <li key={pair.id} className="rounded-md px-2 py-1 hover:bg-slate-800">
                {pair.sourceField}
              </li>
            ))}
            <li className="rounded-md px-2 py-1 text-slate-500">…</li>
          </ul>
        </div>
        <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950/80 p-3 text-xs">
          <p className="font-medium text-slate-300">Field coverage</p>
          <div className="mt-2 h-1.5 rounded-full bg-slate-800">
            <div className="h-full rounded-full bg-brand" style={{ width: `${coverage}%` }} />
          </div>
          <p className="mt-1 text-slate-400">{coverage}% mapped ({pairs.length} fields)</p>
        </div>
      </aside>

      <section className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
        <header className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">Field Mappings</h2>
            <p className="text-xs text-slate-500">Drag to reorder priority · double-click to edit</p>
          </div>
          <button className="rounded-lg bg-slate-800 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-700">Auto-match</button>
        </header>
        <div className="mt-4 flex-1 overflow-y-auto pr-1">
          <ul className="space-y-2">
            {pairs.map((pair) => (
              <li
                key={pair.id}
                onClick={() => setSelectedMappingId(pair.id)}
                className={`cursor-pointer rounded-xl border px-3 py-2 text-sm transition-colors ${
                  selectedMapping?.id === pair.id
                    ? 'border-brand/60 bg-slate-800/80'
                    : 'border-slate-800 bg-slate-900/40 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-slate-100">{pair.targetField.split('/').pop()}</p>
                    <p className="text-xs text-slate-400">{pair.sourceField}</p>
                  </div>
                  <span className={`rounded-full px-2 py-0.5 text-xs font-semibold uppercase tracking-wide ${getStatusStyles(pair.status)}`}>
                    {pair.status.replace('-', ' ')}
                  </span>
                </div>
                <p className="mt-2 text-xs text-slate-300">Transformation: {pair.transformation}</p>
                <p className="mt-1 rounded bg-slate-950/80 px-2 py-1 font-mono text-xs text-slate-200">{pair.preview}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
        <header className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-white">Mapping Details</h2>
            <p className="text-xs text-slate-500">Review transformation preview before publishing</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="rounded-lg bg-emerald-500 px-3 py-1 text-xs font-semibold text-emerald-950 shadow hover:bg-emerald-400"
              onClick={() => updateMappingStatus(selectedMapping?.id ?? '', 'complete')}
            >
              Mark complete
            </button>
            <button
              className="rounded-lg bg-amber-500/20 px-3 py-1 text-xs font-semibold text-amber-200 hover:bg-amber-500/30"
              onClick={() => updateMappingStatus(selectedMapping?.id ?? '', 'needs-review')}
            >
              Needs review
            </button>
          </div>
        </header>
        <div className="mt-4 grow space-y-4 overflow-y-auto pr-1 text-sm text-slate-200">
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-3">
            <h3 className="text-sm font-semibold text-slate-100">Selected Target</h3>
            <p className="mt-1 text-xs text-slate-400">{selectedMapping?.targetField}</p>
            <p className="mt-2 text-slate-200">Source preview:</p>
            <pre className="mt-2 max-h-32 overflow-auto rounded-lg bg-slate-900/80 p-3 text-xs text-slate-300">{selectedMapping?.preview}</pre>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-3 text-xs text-slate-300">
            <h3 className="text-sm font-semibold text-slate-100">Suggested Actions</h3>
            <ul className="mt-2 space-y-2">
              {selectedMapping?.status === 'needs-review' && (
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-2 w-2 rounded-full bg-amber-400" />
                  Refine concatenation to drop duplicate punctuation.
                </li>
              )}
              {selectedMapping?.status === 'missing' && (
                <li className="flex items-start gap-2">
                  <span className="mt-1 h-2 w-2 rounded-full bg-rose-400" />
                  Provide Groovy script for generating persistent identifiers.
                </li>
              )}
              <li className="flex items-start gap-2">
                <span className="mt-1 h-2 w-2 rounded-full bg-emerald-400" />
                Preview 10 sample records to validate output coverage.
              </li>
            </ul>
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-3 text-xs text-slate-300">
            <h3 className="text-sm font-semibold text-slate-100">Dependencies</h3>
            <ul className="mt-2 space-y-1">
              <li>• Groovy helper: <code className="font-mono text-emerald-300">buildIiifManifest()</code></li>
              <li>• Controlled vocabulary: RKD artists API</li>
              <li>• Output requires edm:isShownAt</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};
