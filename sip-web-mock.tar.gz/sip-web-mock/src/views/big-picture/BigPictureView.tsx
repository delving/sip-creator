import { pipelineStages } from '../../data/datasets';
import { histograms } from '../../data/stats';
import { HistogramCard } from '../../components/charts/Histogram';
import { useSelectedDataset } from '../../state/workspaceStore';

const PipelineTimeline = () => {
  return (
    <ol className="space-y-4">
      {pipelineStages.map((stage, index) => (
        <li key={stage.id} className="relative flex items-start gap-4">
          {index !== pipelineStages.length - 1 && (
            <span className="absolute left-3 top-6 h-full w-px bg-slate-800" aria-hidden="true" />
          )}
          <span
            className={`mt-1 flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${
              stage.state === 'done'
                ? 'bg-emerald-500 text-emerald-950'
                : stage.state === 'in-progress'
                ? 'bg-brand text-white'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            {index + 1}
          </span>
          <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">{stage.title}</h3>
              <span className="text-xs uppercase tracking-wide text-slate-500">{stage.owner}</span>
            </div>
            <p className="mt-2 text-xs text-slate-300">{stage.description}</p>
            <p className="mt-3 text-xs text-slate-500">Status: {stage.state.replace('-', ' ')}</p>
          </div>
        </li>
      ))}
    </ol>
  );
};

export const BigPictureView = () => {
  const dataset = useSelectedDataset();

  return (
    <div className="grid h-full grid-cols-[26rem_minmax(0,1fr)] gap-6 px-6 py-6">
      <section className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
        <header>
          <h2 className="text-lg font-semibold text-white">Processing Timeline</h2>
          <p className="text-xs text-slate-500">Follow the dataset through SIP Creator pipeline</p>
        </header>
        <div className="mt-4 flex-1 overflow-y-auto pr-2">
          <PipelineTimeline />
        </div>
      </section>
      <section className="flex h-full flex-col overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/40">
        <header className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
          <div>
            <h2 className="text-lg font-semibold text-white">Dataset Health</h2>
            <p className="text-xs text-slate-500">{dataset?.name ?? 'Select a dataset'} summary</p>
          </div>
          <button className="text-xs font-semibold text-brand hover:text-brand-light">Export report</button>
        </header>
        <div className="grid flex-1 grid-cols-2 gap-4 overflow-y-auto p-4">
          {histograms.map((histogram) => (
            <HistogramCard key={histogram.id} histogram={histogram} />
          ))}
          <article className="col-span-2 rounded-2xl border border-slate-800 bg-slate-950/60 p-4">
            <h3 className="text-sm font-semibold text-slate-100">Readiness Checklist</h3>
            <ul className="mt-3 grid grid-cols-2 gap-3 text-xs text-slate-300">
              <li className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
                <p className="font-medium text-emerald-300">Source Integrity</p>
                <p className="mt-1 text-slate-400">18,432 / 18,432 records parsed successfully.</p>
              </li>
              <li className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
                <p className="font-medium text-amber-300">Mapping Coverage</p>
                <p className="mt-1 text-slate-400">4 fields require manual review.</p>
              </li>
              <li className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
                <p className="font-medium text-slate-200">Validation</p>
                <p className="mt-1 text-slate-400">Pending – run after mapping tweaks.</p>
              </li>
              <li className="rounded-lg border border-slate-800 bg-slate-900/60 p-3">
                <p className="font-medium text-slate-200">Publication</p>
                <p className="mt-1 text-slate-400">Scheduled for handoff this week.</p>
              </li>
            </ul>
          </article>
        </div>
      </section>
    </div>
  );
};
