import { Fragment, useCallback, useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { useWorkspaceStore } from '../../state/workspaceStore';
import { datasets as fixtureDatasets } from '../../data/datasets';

type RemoteDataset = {
  spec: string;
  title: string;
  orgId: string;
  latestVersion: string;
  availableVersions: number;
  status: 'published' | 'draft' | 'archived';
};

type LocalDatasetVersion = {
  id: string;
  label: string;
  timestamp: string;
  folderPath: string;
  schemaVersion: string;
  state: 'processed' | 'mapping' | 'analyzed' | 'sourced';
  facts: Record<string, string>;
};

type LocalDatasetGroup = {
  spec: string;
  title: string;
  orgId: string;
  type: string;
  schemaVersion: string;
  latestTimestamp: string | null;
  versionCount: number;
  versions: LocalDatasetVersion[];
};

type UploadItem = {
  file: string;
  spec: string;
  schema: string;
  size: number;
  modified: string;
};

type Credentials = {
  narthexUrl: string;
  narthexUsername: string;
  narthexPassword: string;
};

const DEFAULT_CREDENTIALS: Credentials = {
  narthexUrl: '',
  narthexUsername: '',
  narthexPassword: ''
};

const REMOTE_FALLBACK: RemoteDataset[] = [
  {
    spec: 'amsterdam-museum',
    title: 'Amsterdam Museum',
    orgId: 'dcn',
    latestVersion: '2025-01-12T10:30:00Z',
    availableVersions: 6,
    status: 'published'
  },
  {
    spec: 'anne-frank-stichting',
    title: 'Anne Frank Stichting',
    orgId: 'dcn',
    latestVersion: '2025-04-01T12:57:00Z',
    availableVersions: 9,
    status: 'draft'
  },
  {
    spec: 'museum-weesp',
    title: 'Museum Weesp',
    orgId: 'dcn',
    latestVersion: '2025-02-03T09:32:00Z',
    availableVersions: 3,
    status: 'published'
  }
];

const toLocaleDate = (timestamp: string | null) => {
  if (!timestamp) return 'Unknown';
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return 'Unknown';
  return date.toLocaleString('en-GB', {
    year: 'numeric',
    month: 'short',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
};

const formatBytes = (bytes: number) => {
  const thresh = 1024;
  if (Math.abs(bytes) < thresh) {
    return `${bytes} B`;
  }
  const units = ['KB', 'MB', 'GB', 'TB'];
  let u = -1;
  let value = bytes;
  do {
    value /= thresh;
    ++u;
  } while (Math.abs(value) >= thresh && u < units.length - 1);
  return `${value.toFixed(1)} ${units[u]}`;
};

const useJsonFetch = async <T,>(url: string, options?: RequestInit) => {
  const response = await fetch(url, options);
  const text = await response.text();

  if (!response.ok) {
    try {
      const payload = JSON.parse(text);
      const error = new Error(payload.error ?? `${response.status} ${response.statusText}`);
      (error as any).status = response.status;
      (error as any).payload = payload;
      throw error;
    } catch (parsingError) {
      const error = new Error(`${response.status} ${response.statusText}`);
      (error as any).status = response.status;
      (error as any).rawBody = text;
      throw error;
    }
  }

  return JSON.parse(text) as T;
};

const buildFallbackGroups = (): LocalDatasetGroup[] =>
  fixtureDatasets.map<LocalDatasetGroup>((dataset) => ({
    spec: dataset.spec,
    title: dataset.name,
    orgId: dataset.orgId,
    type: dataset.type,
    schemaVersion: dataset.schemaVersion,
    latestTimestamp: dataset.lastSynced,
    versionCount: 1,
    versions: [
      {
        id: `${dataset.spec}__mock`,
        label: toLocaleDate(dataset.lastSynced),
        timestamp: dataset.lastSynced,
        folderPath: `/mock/${dataset.spec}`,
        schemaVersion: dataset.schemaVersion,
        state: dataset.status === 'processed' ? 'processed' : dataset.status === 'mapping' ? 'mapping' : 'analyzed',
        facts: {
          name: dataset.name,
          orgId: dataset.orgId,
          type: dataset.type,
          rights: dataset.rights
        }
      }
    ]
  }));

type CredentialsDialogProps = {
  open: boolean;
  initialCredentials: Credentials;
  onClose: () => void;
  onSubmit: (credentials: Credentials) => void;
  sourcePath?: string;
  submitting: boolean;
  error?: string | null;
};

type VersionDetailContext = {
  group: LocalDatasetGroup;
  version: LocalDatasetVersion;
};

const CredentialsDialog = ({
  open,
  onClose,
  onSubmit,
  initialCredentials,
  sourcePath,
  submitting,
  error
}: CredentialsDialogProps) => {
  const [values, setValues] = useState(initialCredentials);

  useEffect(() => {
    setValues(initialCredentials);
  }, [initialCredentials, open]);

  const updateField = (field: keyof Credentials) => (event: React.ChangeEvent<HTMLInputElement>) => {
    setValues((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    onSubmit(values);
  };

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-200"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-150"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center px-4 py-8">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-200"
              enterFrom="opacity-0 translate-y-4"
              enterTo="opacity-100 translate-y-0"
              leave="ease-in duration-150"
              leaveFrom="opacity-100 translate-y-0"
              leaveTo="opacity-0 translate-y-4"
            >
              <Dialog.Panel className="w-full max-w-lg rounded-2xl border border-slate-800 bg-slate-950/95 p-6 shadow-xl">
                <Dialog.Title className="text-lg font-semibold text-white">Authenticate with Narthex</Dialog.Title>
                <p className="mt-1 text-sm text-slate-400">
                  Enter the credentials stored in <code className="font-mono text-slate-200">sip-creator.properties</code>
                  {sourcePath ? ` (${sourcePath})` : ''}.
                </p>
                <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
                  <div>
                    <label className="block text-xs font-medium uppercase tracking-wide text-slate-400">Narthex URL</label>
                    <input
                      type="url"
                      required
                      value={values.narthexUrl}
                      onChange={updateField('narthexUrl')}
                      className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                      placeholder="https://example.org/narthex"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wide text-slate-400">Username</label>
                      <input
                        type="text"
                        required
                        value={values.narthexUsername}
                        onChange={updateField('narthexUsername')}
                        className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium uppercase tracking-wide text-slate-400">Password</label>
                      <input
                        type="password"
                        required
                        value={values.narthexPassword}
                        onChange={updateField('narthexPassword')}
                        className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
                      />
                    </div>
                  </div>
                  {error ? <p className="text-sm text-rose-400">{error}</p> : null}
                  <div className="mt-6 flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={onClose}
                      className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white shadow hover:bg-brand-dark disabled:cursor-wait disabled:opacity-60"
                      disabled={submitting}
                    >
                      {submitting ? 'Refreshing…' : 'Refresh list'}
                    </button>
                  </div>
                </form>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

const DatasetVersionModal = ({
  context,
  open,
  onClose,
  onSelect
}: {
  context: VersionDetailContext | null;
  open: boolean;
  onClose: () => void;
  onSelect: (group: LocalDatasetGroup, version: LocalDatasetVersion) => void;
}) => {
  if (!context) return null;
  const { group, version } = context;

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog as="div" className="relative z-50" onClose={onClose}>
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-200"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-150"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm" />
        </Transition.Child>

        <div className="fixed inset-0 overflow-y-auto">
          <div className="flex min-h-full items-center justify-center px-4 py-8">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-200"
              enterFrom="opacity-0 translate-y-6"
              enterTo="opacity-100 translate-y-0"
              leave="ease-in duration-150"
              leaveFrom="opacity-100 translate-y-0"
              leaveTo="opacity-0 translate-y-6"
            >
              <Dialog.Panel className="w-full max-w-3xl rounded-3xl border border-slate-800 bg-slate-950/95 shadow-xl">
                <header className="flex items-center justify-between border-b border-slate-800 px-6 py-4">
                  <div>
                    <Dialog.Title className="text-lg font-semibold text-white">{group.title}</Dialog.Title>
                    <p className="text-xs text-slate-500">{group.spec} · {group.schemaVersion} · {group.type}</p>
                  </div>
                  <p className="text-xs text-slate-500">{toLocaleDate(version.timestamp)}</p>
                </header>
                <div className="grid grid-cols-[minmax(0,1fr)_20rem] gap-6 px-6 py-6">
                  <section>
                    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-sm text-slate-200">
                      <dl className="grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <dt className="uppercase tracking-wide text-slate-500">Folder</dt>
                          <dd className="text-slate-200">{version.folderPath}</dd>
                        </div>
                        <div>
                          <dt className="uppercase tracking-wide text-slate-500">State</dt>
                          <dd className="capitalize text-slate-200">{version.state}</dd>
                        </div>
                        <div>
                          <dt className="uppercase tracking-wide text-slate-500">Schema</dt>
                          <dd className="text-slate-200">{version.schemaVersion}</dd>
                        </div>
                        <div>
                          <dt className="uppercase tracking-wide text-slate-500">Organisation</dt>
                          <dd className="text-slate-200">{group.orgId}</dd>
                        </div>
                      </dl>
                    </div>
                    <div className="mt-6">
                      <h3 className="text-sm font-semibold text-slate-100">Dataset facts</h3>
                      <div className="mt-3 grid grid-cols-2 gap-3 text-xs">
                        {Object.entries(version.facts).map(([key, value]) => (
                          <div key={key} className="rounded-2xl border border-slate-800 bg-slate-900/70 p-3">
                            <p className="text-[11px] uppercase tracking-wide text-slate-500">{key}</p>
                            <p className="mt-1 break-words text-slate-200">{value}</p>
                          </div>
                        ))}
                        {Object.keys(version.facts).length === 0 ? (
                          <p className="col-span-2 rounded-2xl border border-slate-800 bg-slate-900/70 p-4 text-slate-400">
                            No facts found in <code className="font-mono">sip.json</code> or <code className="font-mono">narthex_facts.txt</code>.
                          </p>
                        ) : null}
                      </div>
                    </div>
                  </section>
                  <aside className="flex flex-col gap-4 text-sm text-slate-200">
                    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
                      <h4 className="text-sm font-semibold text-slate-100">Actions</h4>
                      <p className="mt-2 text-xs text-slate-400">Use this version as the active mapping workspace.</p>
                      <button
                        onClick={() => onSelect(group, version)}
                        className="mt-4 w-full rounded-lg bg-brand px-4 py-2 text-sm font-semibold text-white shadow hover:bg-brand-dark"
                      >
                        Use for mapping
                      </button>
                    </div>
                    <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4 text-xs text-slate-300">
                      <h4 className="text-sm font-semibold text-slate-100">Related files</h4>
                      <ul className="mt-2 space-y-2">
                        <li>
                          <span className="font-mono text-emerald-300">mapping_*.xml</span> – Groovy mapping snapshots
                        </li>
                        <li>
                          <span className="font-mono text-emerald-300">report.json</span> – Latest validation report
                        </li>
                        <li>
                          <span className="font-mono text-emerald-300">source.xml.gz</span> – Source ingest copy
                        </li>
                      </ul>
                    </div>
                  </aside>
                </div>
                <footer className="flex items-center justify-end gap-3 border-t border-slate-800 px-6 py-4">
                  <button
                    onClick={onClose}
                    className="rounded-lg border border-slate-700 px-4 py-2 text-sm font-medium text-slate-300 hover:bg-slate-800"
                  >
                    Close
                  </button>
                </footer>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
};

const RemoteDatasetsColumn = ({
  datasets,
  loading,
  error,
  onRefresh,
  hasFetched,
  lastFetchedAt
}: {
  datasets: RemoteDataset[];
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  hasFetched: boolean;
  lastFetchedAt: string | null;
}) => {
  const total = datasets.length;
  return (
    <section className="flex h-full min-h-0 flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Remote datasets</h2>
          <p className="text-xs text-slate-500">Narthex catalogue · {total} dataset{total === 1 ? '' : 's'}</p>
        </div>
        <button
          onClick={onRefresh}
          className="rounded-lg bg-brand px-3 py-1.5 text-xs font-semibold text-white shadow hover:bg-brand-dark disabled:opacity-60"
          disabled={loading}
        >
          {loading ? 'Refreshing…' : 'Refresh'}
        </button>
      </header>
      <div className="mt-3 text-xs text-slate-500">
        {lastFetchedAt ? `Last refreshed ${toLocaleDate(lastFetchedAt)}` : 'Press refresh to fetch from Narthex'}
      </div>
      <div className="mt-4 flex-1 overflow-y-auto pr-1">
        {error ? (
          <div className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200">
            {error}
          </div>
        ) : null}
        {!datasets.length && hasFetched && !loading ? (
          <p className="text-sm text-slate-400">No datasets found in remote catalogue.</p>
        ) : null}
        <ul className="space-y-3 pb-2">
          {datasets.map((dataset) => (
            <li key={dataset.spec} className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-slate-100">{dataset.title}</p>
                  <p className="text-xs text-slate-500">{dataset.spec} · {dataset.orgId}</p>
                </div>
                <span
                  className={`rounded-full px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide ${
                    dataset.status === 'published'
                      ? 'bg-emerald-500/20 text-emerald-200'
                      : dataset.status === 'draft'
                      ? 'bg-amber-500/20 text-amber-200'
                      : 'bg-slate-700 text-slate-100'
                  }`}
                >
                  {dataset.status}
                </span>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-xs text-slate-300">
                <div>
                  <p className="text-slate-500">Latest version</p>
                  <p className="font-medium text-slate-200">{toLocaleDate(dataset.latestVersion)}</p>
                </div>
                <div>
                  <p className="text-slate-500">Versions</p>
                  <p className="font-medium text-slate-200">{dataset.availableVersions}</p>
                </div>
              </div>
              <div className="mt-3 flex items-center justify-end gap-2">
                <button className="rounded-lg border border-slate-700 px-3 py-1 text-xs font-semibold text-slate-300 hover:bg-slate-800">
                  Preview
                </button>
                <button className="rounded-lg bg-slate-800 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-700">
                  Download
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
};

const LocalDatasetsColumn = ({
  groups,
  loading,
  error,
  onReload,
  selectedGroupSpec,
  onSelectGroup,
  selectedVersionId,
  onInspectVersion,
  onQuickSelectVersion
}: {
  groups: LocalDatasetGroup[];
  loading: boolean;
  error: string | null;
  onReload: () => void;
  selectedGroupSpec: string | null;
  onSelectGroup: (spec: string) => void;
  selectedVersionId: string | null;
  onInspectVersion: (group: LocalDatasetGroup, version: LocalDatasetVersion) => void;
  onQuickSelectVersion: (group: LocalDatasetGroup, version: LocalDatasetVersion) => void;
}) => {
  const selectedGroup = groups.find((group) => group.spec === selectedGroupSpec) ?? groups[0];

  return (
    <section className="flex h-full min-h-0 flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-white">Downloaded datasets</h2>
          <p className="text-xs text-slate-500">Local workspace snapshots grouped by dataset</p>
        </div>
        <button
          onClick={onReload}
          className="rounded-lg border border-slate-700 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-800 disabled:opacity-60"
          disabled={loading}
        >
          {loading ? 'Loading…' : 'Reload'}
        </button>
      </header>
      {error ? <p className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm text-amber-200">{error}</p> : null}
      <div className="mt-4 grid flex-1 grid-cols-[18rem_minmax(0,1fr)] gap-4 overflow-hidden">
        <div className="flex min-h-0 flex-col overflow-hidden">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-500">Datasets ({groups.length})</h3>
          <div className="mt-2 flex-1 overflow-y-auto pr-1">
            <ul className="space-y-2 text-sm">
              {groups.map((group) => (
                <li key={group.spec}>
                  <button
                    onClick={() => onSelectGroup(group.spec)}
                    className={`w-full rounded-xl border px-3 py-2 text-left transition-colors ${
                      selectedGroup?.spec === group.spec
                        ? 'border-brand/70 bg-slate-800/80 shadow'
                        : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900/70'
                    }`}
                  >
                    <p className="text-sm font-semibold text-slate-100">{group.title}</p>
                    <p className="text-xs text-slate-500">{group.spec} · {group.versionCount} version{group.versionCount === 1 ? '' : 's'}</p>
                    <p className="mt-1 text-xs text-slate-400">Last updated {toLocaleDate(group.latestTimestamp)}</p>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="flex min-h-0 flex-col overflow-hidden rounded-2xl border border-slate-800 bg-slate-950/50">
          <header className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
            <div>
              <p className="text-sm font-semibold text-slate-100">{selectedGroup?.title ?? 'Select a dataset'}</p>
              {selectedGroup ? (
                <p className="text-xs text-slate-500">{selectedGroup.schemaVersion} · {selectedGroup.type}</p>
              ) : null}
            </div>
            {selectedGroup ? <span className="text-xs text-slate-400">{selectedGroup.orgId}</span> : null}
          </header>
          <div className="flex-1 overflow-y-auto p-4 text-sm text-slate-200">
            {selectedGroup ? (
              <ul className="space-y-3">
                {selectedGroup.versions.map((version) => (
                  <li
                    key={version.id}
                    className={`rounded-2xl border px-4 py-3 text-xs transition-colors ${
                      selectedVersionId === version.id
                        ? 'border-brand/60 bg-slate-900/80'
                        : 'border-slate-800 bg-slate-900/50 hover:border-slate-700 hover:bg-slate-900/70'
                    }`}
                  >
                    <div className="flex items-center justify-between text-sm">
                      <p className="font-semibold text-slate-100">{version.label}</p>
                      <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[11px] uppercase tracking-wide text-slate-300">
                        {version.state}
                      </span>
                    </div>
                    <p className="mt-1 font-mono text-[11px] text-slate-500">{version.folderPath}</p>
                    <div className="mt-3 flex items-center justify-end gap-2">
                      <button
                        onClick={() => onQuickSelectVersion(selectedGroup, version)}
                        className="rounded-lg border border-slate-700 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-800"
                      >
                        Use for mapping
                      </button>
                      <button
                        onClick={() => onInspectVersion(selectedGroup, version)}
                        className="rounded-lg bg-brand px-3 py-1 text-xs font-semibold text-white shadow hover:bg-brand-dark"
                      >
                        View details
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-sm text-slate-500">Select a dataset to see downloaded versions.</p>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

const UploadQueueColumn = ({ items, error }: { items: UploadItem[]; error: string | null }) => {
  return (
    <section className="flex h-full min-h-0 flex-col rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">Upload queue</h2>
          <p className="text-xs text-slate-500">SIP packages ready for Narthex</p>
        </div>
        <button className="rounded-lg bg-slate-800 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-slate-700">
          Upload selected
        </button>
      </header>
      {error ? <p className="mt-3 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm text-amber-200">{error}</p> : null}
      <div className="mt-4 flex-1 overflow-y-auto pr-1">
        <ul className="space-y-3 text-sm">
          {items.map((item) => (
            <li key={item.file} className="rounded-xl border border-slate-800 bg-slate-900/60 p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold text-slate-100">{item.file}</p>
                  <p className="text-xs text-slate-500">{item.spec} · {item.schema}</p>
                </div>
                <span className="text-xs text-slate-400">{toLocaleDate(item.modified)}</span>
              </div>
              <div className="mt-2 flex items-center justify-between text-xs text-slate-300">
                <p>{formatBytes(item.size)}</p>
                <div className="flex items-center gap-2">
                  <button className="rounded-lg border border-slate-700 px-2 py-1 text-xs text-slate-200 hover:bg-slate-800">Inspect</button>
                  <button className="rounded-lg bg-brand px-2 py-1 text-xs font-semibold text-white shadow hover:bg-brand-dark">Upload</button>
                </div>
              </div>
            </li>
          ))}
          {!items.length ? <p className="text-sm text-slate-500">No SIP packages queued for upload.</p> : null}
        </ul>
      </div>
    </section>
  );
};

export const DatasetsView = () => {
  const selectDataset = useWorkspaceStore((state) => state.selectDataset);

  const [remoteDatasets, setRemoteDatasets] = useState<RemoteDataset[]>([]);
  const [remoteLoading, setRemoteLoading] = useState(false);
  const [remoteError, setRemoteError] = useState<string | null>(null);
  const [remoteFetchedAt, setRemoteFetchedAt] = useState<string | null>(null);
  const [hasFetchedRemote, setHasFetchedRemote] = useState(false);

  const [localGroups, setLocalGroups] = useState<LocalDatasetGroup[]>([]);
  const [localLoading, setLocalLoading] = useState(true);
  const [localError, setLocalError] = useState<string | null>(null);

  const [uploadItems, setUploadItems] = useState<UploadItem[]>([]);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const [credentials, setCredentials] = useState<Credentials>(DEFAULT_CREDENTIALS);
  const [credentialsSource, setCredentialsSource] = useState<string | undefined>();
  const [credentialsError, setCredentialsError] = useState<string | null>(null);
  const [credentialsModalOpen, setCredentialsModalOpen] = useState(false);

  const [selectedGroupSpec, setSelectedGroupSpec] = useState<string | null>(null);
  const [selectedVersionId, setSelectedVersionId] = useState<string | null>(null);
  const [versionDetailContext, setVersionDetailContext] = useState<VersionDetailContext | null>(null);
  const [versionDetailOpen, setVersionDetailOpen] = useState(false);

  const fetchCredentials = useCallback(async () => {
    try {
      const response = await useJsonFetch<{ credentials: Credentials; source: string }>('/api/credentials');
      setCredentials(response.credentials);
      setCredentialsSource(response.source);
    } catch {
      setCredentialsSource(undefined);
      setCredentials(DEFAULT_CREDENTIALS);
    }
  }, []);

  const fetchLocalGroups = useCallback(async () => {
    setLocalLoading(true);
    setLocalError(null);
    try {
      const response = await useJsonFetch<{ groups: LocalDatasetGroup[] }>('/api/local-datasets');
      setLocalGroups(response.groups);
      if (response.groups.length) {
        setSelectedGroupSpec(response.groups[0].spec);
        setSelectedVersionId(response.groups[0].versions[0]?.id ?? null);
      }
    } catch (error) {
      console.warn('Falling back to fixtures for local datasets:', error);
      const fallback = buildFallbackGroups();
      setLocalGroups(fallback);
      if (fallback.length) {
        setSelectedGroupSpec(fallback[0].spec);
        setSelectedVersionId(fallback[0].versions[0]?.id ?? null);
      }
      setLocalError('Unable to read local workspace; showing fixture data.');
    } finally {
      setLocalLoading(false);
    }
  }, []);

  const fetchUploadQueue = useCallback(async () => {
    try {
      const response = await useJsonFetch<{ items: UploadItem[] }>('/api/upload-queue');
      setUploadItems(response.items);
    } catch {
      setUploadError('Unable to read upload queue; showing empty list.');
      setUploadItems([]);
    }
  }, []);

  const refreshRemoteDatasets = useCallback(
    async (creds: Credentials) => {
      setRemoteLoading(true);
      setRemoteError(null);
      setCredentialsError(null);
      try {
        const response = await useJsonFetch<{ datasets: RemoteDataset[]; fetchedAt: string }>('/api/remote-datasets', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(creds)
        });
        setRemoteDatasets(response.datasets);
        setRemoteFetchedAt(response.fetchedAt);
        setHasFetchedRemote(true);
        setCredentials(creds);
      } catch (error: any) {
        console.warn('Unable to fetch remote datasets, falling back to defaults:', error);
        setRemoteDatasets(REMOTE_FALLBACK);
        const serverMessage = error?.payload?.error ?? error?.message ?? 'Unable to reach Narthex; showing static sample list.';
        setRemoteError(serverMessage);
        setRemoteFetchedAt(new Date().toISOString());
        setHasFetchedRemote(true);
        setCredentialsError(
          error?.status === 401
            ? 'Credentials were rejected by Narthex.'
            : 'Unable to reach Narthex; please verify the URL or try again later.'
        );
      } finally {
        setRemoteLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    fetchCredentials();
    fetchLocalGroups();
    fetchUploadQueue();
  }, [fetchCredentials, fetchLocalGroups, fetchUploadQueue]);

  const handleSelectGroup = useCallback((spec: string) => {
    setSelectedGroupSpec(spec);
    const group = localGroups.find((item) => item.spec === spec);
    const firstVersion = group?.versions[0];
    setSelectedVersionId(firstVersion?.id ?? null);
    if (group) {
      selectDataset(group.spec);
    }
  }, [localGroups, selectDataset]);

  const handleQuickSelectVersion = useCallback((group: LocalDatasetGroup, version: LocalDatasetVersion) => {
    setSelectedGroupSpec(group.spec);
    setSelectedVersionId(version.id);
    selectDataset(group.spec);
  }, [selectDataset]);

  const handleInspectVersion = useCallback((group: LocalDatasetGroup, version: LocalDatasetVersion) => {
    setSelectedGroupSpec(group.spec);
    setSelectedVersionId(version.id);
    setVersionDetailContext({ group, version });
    setVersionDetailOpen(true);
  }, []);

  const handleUseVersionFromModal = useCallback((group: LocalDatasetGroup, version: LocalDatasetVersion) => {
    setVersionDetailOpen(false);
    setSelectedGroupSpec(group.spec);
    setSelectedVersionId(version.id);
    selectDataset(group.spec);
  }, [selectDataset]);

  const openCredentialsModal = useCallback(() => {
    setCredentialsModalOpen(true);
  }, []);

  const closeCredentialsModal = useCallback(() => {
    setCredentialsModalOpen(false);
  }, []);

  const handleCredentialsSubmit = useCallback(
    (updated: Credentials) => {
      setCredentialsModalOpen(false);
      refreshRemoteDatasets(updated);
    },
    [refreshRemoteDatasets]
  );

  return (
    <div className="grid h-full min-h-0 grid-cols-[22rem_minmax(0,1fr)_20rem] gap-6 overflow-hidden px-6 py-6">
      <RemoteDatasetsColumn
        datasets={[...remoteDatasets].sort((a, b) => a.spec.localeCompare(b.spec))}
        loading={remoteLoading}
        error={remoteError}
        onRefresh={openCredentialsModal}
        hasFetched={hasFetchedRemote}
        lastFetchedAt={remoteFetchedAt}
      />
      <LocalDatasetsColumn
        groups={localGroups}
        loading={localLoading}
        error={localError}
        onReload={fetchLocalGroups}
        selectedGroupSpec={selectedGroupSpec ?? localGroups[0]?.spec ?? null}
        onSelectGroup={handleSelectGroup}
        selectedVersionId={selectedVersionId}
        onInspectVersion={handleInspectVersion}
        onQuickSelectVersion={handleQuickSelectVersion}
      />
      <UploadQueueColumn items={uploadItems} error={uploadError} />
      <CredentialsDialog
        open={credentialsModalOpen}
        onClose={closeCredentialsModal}
        onSubmit={handleCredentialsSubmit}
        initialCredentials={credentials}
        sourcePath={credentialsSource}
        submitting={remoteLoading}
        error={credentialsError}
      />
      <DatasetVersionModal
        context={versionDetailContext}
        open={versionDetailOpen}
        onClose={() => setVersionDetailOpen(false)}
        onSelect={handleUseVersionFromModal}
      />
    </div>
  );
};
