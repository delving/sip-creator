import type { ViewKey } from '../state/workspaceStore';
import { DatasetsView } from './datasets/DatasetsView';
import { QuickMappingView } from './quick-mapping/QuickMappingView';
import { BigPictureView } from './big-picture/BigPictureView';
import { CodeTweakingView } from './code-tweaking/CodeTweakingView';

export type ViewDescriptor = {
  id: ViewKey;
  label: string;
  element: JSX.Element;
};

export const views: ViewDescriptor[] = [
  { id: 'datasets', label: 'Datasets', element: <DatasetsView /> },
  { id: 'quick-mapping', label: 'Quick Mapping', element: <QuickMappingView /> },
  { id: 'big-picture', label: 'Big Picture', element: <BigPictureView /> },
  { id: 'code-tweaking', label: 'Code Tweaking', element: <CodeTweakingView /> }
];
