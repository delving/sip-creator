import { useState } from 'react';
import { groovySnippet } from '../../data/datasets';

const helpers = [
  { name: 'buildIiifManifest(record)', description: 'Construct IIIF manifest URL based on identifier.' },
  { name: 'thumbnailUrl(record)', description: 'Derive thumbnail URL with fallback to placeholder.' },
  { name: 'authorityLookup(vocab, value)', description: 'Resolve preferred label from external authority.' },
  { name: 'join(values, separator)', description: 'Join multi-valued fields with separator.' }
];

const compileStatuses = [
  { time: '16:21:39', message: 'Compilation succeeded', level: 'success' },
  { time: '16:17:12', message: 'Warning: Missing edm:isShownAt for 4 records', level: 'warn' },
  { time: '16:05:02', message: 'Saved mapping_edm.groovy', level: 'info' }
];

export const CodeTweakingView = () => {
  const [code, setCode] = useState(groovySnippet);

  return (
    <div className="grid h-full grid-cols-[minmax(0,1fr)_24rem] gap-6 px-6 py-6">
      <section className="flex h-full flex-col rounded-2xl border border-slate-800 bg-slate-900/40">
        <header className="flex items-center justify-between border-b border-slate-800 px-4 py-3">
          <div>
            <h2 className="text-lg font-semibold text-white">Groovy Mapping Editor</h2>
            <p className="text-xs text-slate-500">Live coding with instant preview</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="rounded-lg bg-slate-800 px-3 py-1 text-xs font-semibold text-slate-200 hover:bg-slate-700">
              Format
            </button>
            <button className="rounded-lg bg-brand px-3 py-1 text-xs font-semibold text-white shadow hover:bg-brand-dark">
              Compile & Preview
            </button>
          </div>
        </header>
        <div className="grid flex-1 grid-cols-[minmax(0,1fr)_18rem] overflow-hidden">
          <div className="flex flex-col">
            <textarea
              value={code}
              onChange={(event) => setCode(event.target.value)}
              spellCheck={false}
              className="h-full w-full flex-1 resize-none bg-transparent p-4 font-mono text-sm leading-relaxed text-slate-100 focus:outline-none"
            />
          </div>
          <div className="border-l border-slate-800 bg-slate-950/60">
            <header className="border-b border-slate-800 px-4 py-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
              Preview Output
            </header>
            <div className="flex h-full flex-col justify-between">
              <pre className="h-full overflow-y-auto px-4 py-3 text-xs text-slate-300">{
`{
  "dc:title": "Schuttersstuk van het Amsterdamse gilde",
  "dc:creator": "Frans Hals (1582–1666)",
  "edm:rights": "http://rightsstatements.org/vocab/InC/1.0/",
  "edm:isShownAt": "https://amsterdammuseum.nl/object/AM12345"
}`
              }</pre>
              <div className="border-t border-slate-800 bg-slate-900/80 px-4 py-3 text-xs text-slate-400">
                Using dataset facts from <span className="font-semibold text-slate-200">Amsterdam Museum</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <aside className="flex h-full flex-col space-y-4">
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40">
          <header className="border-b border-slate-800 px-4 py-3">
            <h3 className="text-sm font-semibold text-slate-100">Helper Library</h3>
            <p className="text-xs text-slate-500">Reusable Groovy functions</p>
          </header>
          <ul className="divide-y divide-slate-800 text-xs text-slate-300">
            {helpers.map((helper) => (
              <li key={helper.name} className="px-4 py-3">
                <p className="font-mono text-emerald-300">{helper.name}</p>
                <p className="mt-1 text-slate-400">{helper.description}</p>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex-1 overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/40">
          <header className="border-b border-slate-800 px-4 py-3">
            <h3 className="text-sm font-semibold text-slate-100">Build Console</h3>
          </header>
          <ul className="h-full overflow-y-auto text-xs">
            {compileStatuses.map((status) => (
              <li key={status.message} className="flex items-start justify-between border-b border-slate-800 px-4 py-3 last:border-b-0">
                <div>
                  <p className="font-mono text-slate-500">{status.time}</p>
                  <p className="mt-1 text-slate-300">{status.message}</p>
                </div>
                <span
                  className={`mt-1 rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                    status.level === 'success'
                      ? 'bg-emerald-500/20 text-emerald-200'
                      : status.level === 'warn'
                      ? 'bg-amber-500/20 text-amber-200'
                      : 'bg-slate-700 text-slate-100'
                  }`}
                >
                  {status.level}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  );
};
