import type { Histogram } from '../../data/stats';

export const HistogramCard = ({ histogram }: { histogram: Histogram }) => {
  const max = Math.max(...histogram.bins.map((bin) => bin.count));

  return (
    <article className="rounded-2xl border border-slate-800 bg-slate-900/40 p-4">
      <h3 className="text-sm font-semibold text-slate-100">{histogram.label}</h3>
      <div className="mt-4 space-y-3">
        {histogram.bins.map((bin) => (
          <div key={bin.key}>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>{bin.key}</span>
              <span>{bin.count.toLocaleString()}</span>
            </div>
            <div className="mt-1 h-2 rounded-full bg-slate-800">
              <div
                className="h-full rounded-full bg-brand"
                style={{ width: `${Math.max(8, (bin.count / max) * 100)}%` }}
              />
            </div>
          </div>
        ))}
      </div>
    </article>
  );
};
