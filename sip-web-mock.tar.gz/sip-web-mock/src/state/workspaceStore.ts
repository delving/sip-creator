import { create } from 'zustand';
import {
  datasets as initialDatasets,
  Dataset,
  DatasetStatus,
  mappingPairs as initialMappingPairs,
  MappingPair,
  pipelineStages as initialStages
} from '../data/datasets';

export type ViewKey = 'datasets' | 'quick-mapping' | 'big-picture' | 'code-tweaking';

export type Task = {
  id: string;
  label: string;
  state: 'queued' | 'running' | 'done';
  progress: number;
};

export type WorkspaceState = {
  view: ViewKey;
  datasets: Dataset[];
  selectedDatasetId: string;
  mappingPairs: MappingPair[];
  pipelineStages: typeof initialStages;
  tasks: Task[];
  setView: (view: ViewKey) => void;
  selectDataset: (id: string) => void;
  updateDatasetStatus: (id: string, status: DatasetStatus, progress: number) => void;
  advanceTask: (id: string, progress: number, done?: boolean) => void;
  updateMappingStatus: (id: string, status: MappingPair['status']) => void;
};

const DEFAULT_TASKS: Task[] = [
  { id: 'ingest', label: 'Ingest source XML', state: 'done', progress: 100 },
  { id: 'analyze', label: 'Analyze source structure', state: 'done', progress: 100 },
  { id: 'mapping', label: 'Run mapping preview', state: 'running', progress: 62 },
  { id: 'validate', label: 'Validate against EDM schema', state: 'queued', progress: 0 }
];

export const useWorkspaceStore = create<WorkspaceState>((set) => ({
  view: 'datasets',
  datasets: initialDatasets,
  selectedDatasetId: initialDatasets[0]?.id ?? '',
  mappingPairs: initialMappingPairs,
  pipelineStages: initialStages,
  tasks: DEFAULT_TASKS,
  setView: (view) => set({ view }),
  selectDataset: (id) => set({ selectedDatasetId: id }),
  updateDatasetStatus: (id, status, progress) =>
    set((state) => ({
      datasets: state.datasets.map((dataset) =>
        dataset.id === id ? { ...dataset, status, progress } : dataset
      )
    })),
  advanceTask: (id, progress, done = false) =>
    set((state) => ({
      tasks: state.tasks.map((task) => {
        if (task.id !== id) return task;
        return {
          ...task,
          progress,
          state: done ? 'done' : progress > 0 ? 'running' : task.state
        };
      })
    })),
  updateMappingStatus: (id, status) =>
    set((state) => ({
      mappingPairs: state.mappingPairs.map((pair) =>
        pair.id === id ? { ...pair, status } : pair
      )
    }))
}));

export const useSelectedDataset = () =>
  useWorkspaceStore((state) =>
    state.datasets.find((dataset) => dataset.id === state.selectedDatasetId)
  );
